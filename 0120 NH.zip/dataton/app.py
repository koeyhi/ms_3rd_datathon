import streamlit as st

pg_list = [
    st.Page("pg/result.py", title="홈"),
    st.Page("pg/player.py", title="player"),
    st.Page("pg/team.py", title="team")
]

pg = st.navigation(pg_list)
pg.run()
