import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터 경로와 파일 로드
DATA_PATH = "data/"  # 데이터 경로를 설정하세요.
team_df = pd.read_csv(f"{DATA_PATH}team.csv")

# 연도, 리그, 팀 선택
years = team_df['year'].unique()
leagues = team_df['league'].unique()

selected_year = st.selectbox('연도를 선택하세요', years)
selected_league = st.selectbox('리그를 선택하세요', leagues)

# 선택된 리그에 맞는 팀 필터링
teams_in_league = team_df[team_df['league'] == selected_league]['teamname'].unique()
selected_team = st.selectbox('팀을 선택하세요', teams_in_league)

# y축에 들어갈 컬럼 선택
columns_to_plot = [col for col in team_df.columns if col not in ['teamname', 'year', 'league', 'gameid', 'position', 'split', 'patch',
                                                                 'ban1','ban2','ban3','ban4','ban5',
                                                                 'pick1','pick2','pick3','pick4','pick5',]]
selected_columns = st.multiselect('y축에 들어갈 컬럼을 선택하세요', columns_to_plot)

# 'mean', 'sum', 'count' 선택
aggregation_method = st.radio("계산 방법을 선택하세요", ('mean', 'sum', 'count'), horizontal=True)

# 데이터 필터링
filtered_df = team_df[(team_df['year'] == selected_year) & 
                      (team_df['league'] == selected_league) & 
                      (team_df['teamname'] == selected_team)]

# # x축을 'patch'로 설정하고 집계 (mean, sum, count)
# aggregated_data = None
# if aggregation_method == 'mean':
#     aggregated_data = filtered_df.groupby('patch')[selected_columns].mean()
# elif aggregation_method == 'sum':
#     aggregated_data = filtered_df.groupby('patch')[selected_columns].sum()
# else:  # count
#     aggregated_data = filtered_df.groupby('patch')[selected_columns].count()

# # 그래프 그리기
# fig, ax = plt.subplots(figsize=(10, 6))
# aggregated_data.plot(kind='bar', ax=ax)
# ax.set_title(f'{selected_team} - {selected_year} ({selected_league})')
# ax.set_xlabel('Patch')
# ax.set_ylabel('Value')
# st.pyplot(fig)
# 필터링된 데이터가 없는 경우 알림 표시
# 필터링된 데이터가 없는 경우 알림 표시
if filtered_df.empty:
    st.warning("선택한 조건에 맞는 데이터가 없습니다.")
else:
    # x축을 'patch'로 설정하고 집계 (mean, sum, count)
    if aggregation_method == 'mean':
        aggregated_data = filtered_df.groupby('patch')[selected_columns].mean()
    elif aggregation_method == 'sum':
        aggregated_data = filtered_df.groupby('patch')[selected_columns].sum()
    else:  # count
        aggregated_data = filtered_df.groupby('patch')[selected_columns].count()

    # 'side' 컬럼이 선택된 경우 병렬 막대그래프 그리기
    if 'side' in selected_columns:
        # 패치별로 blue와 red의 수를 계산
        side_counts = filtered_df.groupby(['patch', 'side']).size().unstack(fill_value=0)

        # 병렬 막대그래프 그리기
        fig, ax = plt.subplots(figsize=(10, 6))
        side_counts.plot(kind='bar', stacked=False, ax=ax, color=['blue', 'red'])
        ax.set_title(f'Side Distribution by Patch - {selected_team} ({selected_year})')
        ax.set_xlabel('Patch')
        ax.set_ylabel('Count')
        st.pyplot(fig)
    else:
        # 'side'가 선택되지 않으면 기존 그래프 그리기
        for col in selected_columns:
            fig, ax = plt.subplots(figsize=(10, 6))

            # 수치형 데이터일 경우 바 차트나 라인 차트
            if pd.api.types.is_numeric_dtype(aggregated_data[col]):
                if len(aggregated_data) > 10:  # 데이터 포인트가 많으면 선 그래프
                    aggregated_data[col].plot(kind='line', ax=ax)
                    ax.set_title(f'{col} - {selected_team} ({selected_year})')
                    ax.set_xlabel('Patch')
                    ax.set_ylabel(col)
                else:  # 데이터 포인트가 적으면 바 차트
                    aggregated_data[col].plot(kind='bar', ax=ax)
                    ax.set_title(f'{col} - {selected_team} ({selected_year})')
                    ax.set_xlabel('Patch')
                    ax.set_ylabel(col)

            # 범주형 데이터일 경우 파이 차트나 히스토그램
            else:
                # 데이터 분포를 보기 위해 히스토그램을 사용
                sns.histplot(filtered_df[col], kde=True, ax=ax)
                ax.set_title(f'{col} Distribution - {selected_team} ({selected_year})')
                ax.set_xlabel(col)
                ax.set_ylabel('Frequency')

            st.pyplot(fig)