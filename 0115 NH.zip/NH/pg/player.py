import streamlit as st
import pandas as pd
import plotly.graph_objects as go

# 데이터 경로와 데이터 로드
DATA_PATH = "data/"
player_df = pd.read_csv(f"{DATA_PATH}player.csv")

# Streamlit 애플리케이션
# st.title("선수별 성과 방사형 그래프")
# st.sidebar.header("필터 설정")

# 사용자가 선택할 옵션 정의
available_years = sorted(player_df['year'].unique())
selected_year = st.selectbox("연도 선택", available_years)

available_leagues = player_df[player_df['year'] == selected_year]['league'].unique()
selected_league = st.selectbox("리그 선택", available_leagues)

available_splits = player_df[
    (player_df['year'] == selected_year) & (player_df['league'] == selected_league)
]['split'].unique()
selected_split = st.selectbox("스플릿 선택", available_splits)

available_players = player_df[
    (player_df['year'] == selected_year) &
    (player_df['league'] == selected_league) &
    (player_df['split'] == selected_split)
]['playername'].unique()
selected_player = st.selectbox("선수 선택", available_players)

# 선택된 선수의 스플릿별 전체 평균 데이터 필터링
filtered_data = player_df[
    (player_df['year'] == selected_year) &
    (player_df['league'] == selected_league) &
    (player_df['split'] == selected_split) &
    (player_df['playername'] == selected_player)
]
# 방사형 그래프를 그리기 위한 데이터 추출
if not filtered_data.empty:
    metrics = ['kda','team kpm','assists','deaths','earned gpm']
    max_values = [20, 20, 20, 20, 300]  # 각 컬럼의 최대값
    avg_values = filtered_data[metrics].mean().tolist()
    normalized_values = [v / max_val for v, max_val in zip(avg_values, max_values)]  # 비율 계산
    
    # 방사형 그래프 생성
    fig = go.Figure()

    # 방사형 그래프 데이터 추가
    fig.add_trace(go.Scatterpolar(
        r=normalized_values + [normalized_values[0]],  # 순환하여 폐곡선 생성
        theta=metrics + [metrics[0]],
        fill='toself',
        name=f"{selected_player}",
        hovertemplate="<b>%{theta}</b><br>Value: %{customdata}<br><extra></extra>",
        customdata=avg_values + [avg_values[0]]  # 원래 값을 hover에 표시
    ))

    # 그래프 레이아웃 설정
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]  # 비율로 그리므로 0~1 사이
            )
        ),
        showlegend=True,
        title=f"{selected_year} {selected_league} - {selected_split}"
    )

    # 그래프 출력
    st.plotly_chart(fig)

else:
    st.warning("선택한 조건에 해당하는 최근 경기 데이터가 없습니다.")