import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터 경로와 파일 로드
DATA_PATH = "data/"  # 데이터 경로를 설정하세요.
player_df = pd.read_csv(f"{DATA_PATH}player.csv")

# 연도, 리그, 팀 선택
years = player_df['year'].unique()
leagues = player_df['league'].unique()

selected_year = st.selectbox('연도', years)
selected_league = st.selectbox('리그', leagues)

# 선택된 리그에 맞는 팀 필터링
players_in_league = player_df[player_df['league'] == selected_league]['playername'].unique()
selected_player = st.selectbox('선수', players_in_league)

#선택한 챔피언 필터링
champions_in_player = player_df[player_df['playername'] == selected_player]['champion'].unique()

# 챔피언을 선택하지 않으면 전체 챔피언에 대한 데이터를 표시
selected_champion = st.selectbox('챔피언 (선택하지 않으면 전체)', ['전체'] + list(champions_in_player))


# y축에 들어갈 컬럼 선택
columns_to_plot = [col for col in player_df.columns if col not in ['playername', 'year', 'league', 'gameid', 'position', 'split', 'patch']]
selected_columns = st.multiselect('데이터', columns_to_plot)

# 'mean', 'sum', 'count' 선택
aggregation_method = st.radio("계산 방법", ('평균', '합', '카운트'), horizontal=True)

# 데이터 필터링
if selected_champion == '전체':
    filtered_df = player_df[(player_df['year'] == selected_year) & 
                          (player_df['league'] == selected_league) & 
                          (player_df['playername'] == selected_player)]
else:
    filtered_df = player_df[(player_df['year'] == selected_year) & 
                          (player_df['league'] == selected_league) & 
                          (player_df['playername'] == selected_player) & 
                          (player_df['champion'] == selected_champion)]

# 필터링된 데이터가 없는 경우 알림 표시
if filtered_df.empty:
    st.warning("선택한 조건에 맞는 데이터가 없습니다.")
else:
    # x축을 'patch'로 설정하고 집계 (mean, sum, count)
    if aggregation_method == 'mean':
        aggregated_data = filtered_df.groupby('patch')[selected_columns].mean()
    elif aggregation_method == 'sum':
        aggregated_data = filtered_df.groupby('patch')[selected_columns].sum()
    else:  # count
        aggregated_data = filtered_df.groupby('patch')[selected_columns].count()

    # 데이터 타입에 따른 그래프 선택
    for col in selected_columns:
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # 수치형 데이터일 경우 바 차트나 라인 차트
        if pd.api.types.is_numeric_dtype(aggregated_data[col]):
            if len(aggregated_data) > 10:  # 데이터 포인트가 많으면 선 그래프
                aggregated_data[col].plot(kind='line', ax=ax)
                ax.set_title(f'{col} - {selected_player} ({selected_year})')
                ax.set_xlabel('Patch')
                ax.set_ylabel(col)
            else:  # 데이터 포인트가 적으면 바 차트
                aggregated_data[col].plot(kind='bar', ax=ax)
                ax.set_title(f'{col} - {selected_player} ({selected_year})')
                ax.set_xlabel('Patch')
                ax.set_ylabel(col)
        
        # 범주형 데이터일 경우 파이 차트나 히스토그램
        else:
            # 데이터 분포를 보기 위해 히스토그램을 사용
            sns.histplot(filtered_df[col], kde=True, ax=ax)
            ax.set_title(f'{col} Distribution - {selected_player} ({selected_year})')
            ax.set_xlabel(col)
            ax.set_ylabel('Frequency')

        st.pyplot(fig)