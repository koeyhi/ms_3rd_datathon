import streamlit as st

pg_list = [
    st.Page("pg/home.py", title="home"),
    st.Page("pg/ttt.py", title="team"),
    st.Page("pg/ppp.py", title="player"),
    st.Page("pg/player.py", title="방사형")
    ]

pg = st.navigation(pg_list)
pg.run()