import streamlit as st

pg_list = [
    st.Page("pg/home.py", title="home"),
    st.Page("pg/ttt.py", title="team"),
    st.Page("pg/ppp.py", title="player")
    ]

pg = st.navigation(pg_list)
pg.run()